import setuptools

setuptools.setup(name='moodscores',
      version='0.1',
      description='sentiment analysis all rolled in one',
      include_package_data=True,
      zip_safe = False,
      packages=setuptools.find_packages()
      # test_suite = 'test'
      )
